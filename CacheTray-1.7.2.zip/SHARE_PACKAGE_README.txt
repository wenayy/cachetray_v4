CacheTray Chrome Extension 1.7.2

Install for testing
1. Extract this ZIP to a folder.
2. In Chrome, open chrome://extensions.
3. Turn on Developer mode.
4. Choose Load unpacked and select the extracted folder (the folder containing manifest.json).

To publish through the Chrome Web Store, upload this ZIP in the Developer Dashboard.

This extension uses CacheTray's hosted transfer service for phone pairing and image/clip transfer. Optional cloud sync uses the Firebase project configured in firebase-config.js. These services are operated separately from this ZIP; recipients do not get their own backend or storage account by installing it. Pro checkout is unavailable until Dodo Payments is configured on the service.

The extension stores captures locally in Chrome by default. Phone transfers are explicit and temporary. Review the privacy policy and service configuration before redistributing to a wider audience.
