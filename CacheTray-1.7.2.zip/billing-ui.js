(function () {
  'use strict';
  const version = chrome.runtime.getManifest().version;
  const byId = id => document.getElementById(id);
  const overlay = document.createElement('div'); overlay.className = 'modal-overlay';
  overlay.id = 'billingModal';
  overlay.innerHTML = `<div class="modal billing-modal" role="dialog" aria-modal="true" aria-labelledby="billingTitle">
    <div class="modal-title" id="billingTitle">CacheTray Pro</div>
    <p class="modal-sub">$4.99/month USD, plus any applicable taxes. Cancel through Manage subscription.</p>
    <p id="billingPlanSummary" class="billing-summary" role="status">Checking your plan…</p>
    <div class="billing-benefits"><p>Free: 5 images on your phone at once · newest 20 clips in each category · 1 phone.</p>
      <p id="proBenefits">Pro: 50 images per phone · newest 100 clips in each category · 2 phones.</p>
      <p>Clips and sent images stay available on your phone for 24 hours.</p></div>
    <div id="billingRecovery" hidden><label for="billingRecoveryKey">Your Pro recovery key</label>
      <input id="billingRecoveryKey" class="phone-pair-input" readonly>
      <p class="modal-sub">Save this key somewhere private. It restores your subscription after reinstalling CacheTray.</p>
      <div class="billing-key-actions"><button id="copyRecovery" type="button" class="modal-btn">Copy key</button>
      <button id="newRecovery" type="button" class="modal-btn">New key</button></div>
      <label class="billing-saved"><input id="recoverySaved" type="checkbox"> I saved my recovery key</label></div>
    <button id="billingCheckout" type="button" class="modal-btn cloud-primary" disabled>Upgrade · $4.99/month</button>
    <button id="billingPortal" type="button" class="modal-btn" hidden>Manage subscription</button>
    <details class="billing-restore"><summary>Restore a paid subscription</summary>
      <label for="restoreRecovery">Saved recovery key</label><input id="restoreRecovery" class="phone-pair-input" autocomplete="off" spellcheck="false" maxlength="64">
      <button id="billingRestore" type="button" class="modal-btn">Restore Pro</button></details>
    <p id="billingError" class="phone-transfer-error" role="alert"></p>
    <div class="modal-actions"><button id="billingClose" type="button" class="modal-btn cancel">Close</button></div></div>`;
  document.body.appendChild(overlay);
  const news = document.createElement('div'); news.className = 'modal-overlay';
  news.innerHTML = `<div class="modal billing-modal" role="dialog" aria-modal="true" aria-labelledby="newsTitle">
    <div class="modal-title" id="newsTitle">What’s new · ${version}</div>
    <ul class="release-notes"><li>Send selected images to your paired phone, with previews, sharing and downloads.</li>
      <li>Recent text, links, code and tasks sync into separate phone categories.</li>
      <li>Go Pro for $4.99/month: 50 images per phone, 100 clips per category, and 2 paired phones.</li>
      <li>Images remember successful sends, with a Send again option.</li>
      <li>Our website is now cachetray.gitflex.lol. Open the phone app there to install it on your home screen.</li>
      <li>Free mobile limits: 5 images on your phone at once and the newest 20 clips per category.</li>
      <li>Pro upgrade and subscription management, when checkout is available.</li>
      <li>More reliable local image saves and clearer phone connection status.</li></ul>
    <p class="modal-sub">Delete a received image or let it expire to free a slot. Local clips stay available in your extension.</p>
    <div class="modal-actions"><button id="newsClose" type="button" class="modal-btn">Got it</button></div></div>`;
  document.body.appendChild(news);
  const bar = document.querySelector('.app-bar-right');
  const planButton = byId('goProBtn') || document.createElement('button'); planButton.type = 'button';
  planButton.className = 'billing-plan-button'; planButton.textContent = 'Go Pro'; planButton.title = 'CacheTray Pro · $4.99/month';
  const newsButton = document.createElement('button'); newsButton.type = 'button';
  newsButton.className = 'billing-news-button icon-action'; newsButton.title = 'What’s new'; newsButton.setAttribute('aria-label', 'What’s new');
  newsButton.textContent = '✦';
  if (!planButton.parentElement) bar?.append(planButton);
  bar?.append(newsButton);
  let account = null;
  let busy = false;
  async function call(message) {
    const result = await chrome.runtime.sendMessage(message);
    if (!result?.ok) throw new Error(result?.error || 'Could not load billing');
    return result;
  }
  function render() {
    const pro = account?.plan === 'pro';
    const available = account?.billing?.available === true;
    const allowance = account?.limits?.imagesPerPhone || 5;
    byId('billingPlanSummary').textContent = `${pro ? 'Pro' : 'Free'} · ${account?.usage?.imagesUsed || 0} sent images available · up to ${allowance} per phone`;
    const cap = account?.limits;
    if (pro && cap) byId('proBenefits').textContent = `Pro: ${cap.imagesPerPhone} images per phone · newest ${cap.clipsPerCategory} clips per category · ${cap.phones} phones.`;
    byId('billingRecovery').hidden = !available && !account?.billing?.subscribed;
    byId('newRecovery').hidden = account?.billing?.subscribed === true;
    byId('billingCheckout').hidden = account?.billing?.subscribed === true || pro;
    byId('billingCheckout').textContent = available ? 'Upgrade · $4.99/month' : 'Pro checkout coming soon';
    byId('billingCheckout').disabled = busy || !available || !byId('recoverySaved').checked;
    byId('billingPortal').hidden = !account?.billing?.hasSubscription;
    planButton.textContent = pro ? 'Pro ✓' : 'Go Pro';
  }
  async function load(newKey = false) {
    const result = await call({ type: 'BILLING_PREPARE', newKey });
    account = result.account;
    byId('billingRecoveryKey').value = result.recoveryKey;
    render();
  }
  async function open() {
    overlay.classList.add('open'); byId('billingError').textContent = '';
    try { await load(); } catch (error) { byId('billingError').textContent = error.message; }
    byId('billingClose').focus();
  }
  const close = () => { overlay.classList.remove('open'); planButton.focus(); };
  planButton.onclick = open;
  byId('billingClose').onclick = close;
  overlay.onclick = event => { if (event.target === overlay) close(); };
  byId('recoverySaved').onchange = render;
  byId('copyRecovery').onclick = async () => {
    try {
      await navigator.clipboard.writeText(byId('billingRecoveryKey').value);
      byId('copyRecovery').textContent = 'Copied ✓';
      setTimeout(() => { byId('copyRecovery').textContent = 'Copy key'; }, 2000);
    } catch (_) { byId('billingError').textContent = 'Select the recovery key and copy it manually.'; }
  };
  byId('newRecovery').onclick = async () => {
    if (!confirm('Replace the key for a new checkout? Keep any earlier key until you know that checkout was not paid.')) return;
    byId('recoverySaved').checked = false;
    try { await load(true); } catch (error) { byId('billingError').textContent = error.message; }
  };
  async function action(name, button) {
    if (busy) return;
    busy = true; button.disabled = true; byId('billingError').textContent = '';
    try {
      await call({ type: 'BILLING_ACTION', action: name, recoveryKey: byId('restoreRecovery').value });
      if (name === 'restore') { await load(); byId('billingError').textContent = 'Subscription restored.'; }
      else byId('billingError').textContent = 'Opened in a browser tab. Your plan updates after payment is verified.';
    } catch (error) { byId('billingError').textContent = error.message; }
    finally { busy = false; button.disabled = false; render(); }
  }
  byId('billingCheckout').onclick = () => action('checkout', byId('billingCheckout'));
  byId('billingPortal').onclick = () => action('portal', byId('billingPortal'));
  byId('billingRestore').onclick = () => action('restore', byId('billingRestore'));
  newsButton.onclick = () => { news.classList.add('open'); byId('newsClose').focus(); };
  byId('newsClose').onclick = async () => {
    news.classList.remove('open'); newsButton.classList.remove('has-update');
    await chrome.storage.local.set({ ct_release_seen: version });
    await chrome.storage.local.remove('ct_release_pending');
    newsButton.focus();
  };
  news.onclick = event => { if (event.target === news) byId('newsClose').click(); };
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { if (overlay.classList.contains('open')) close(); if (news.classList.contains('open')) byId('newsClose').click(); }
  });
  chrome.storage.local.get(['ct_release_pending', 'ct_release_seen']).then(stored => {
    if (stored.ct_release_pending === version && stored.ct_release_seen !== version) {
      newsButton.classList.add('has-update'); newsButton.title = `Updated to ${version} · What’s new`;
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.ct_phone_plan_v1?.newValue) {
      account = changes.ct_phone_plan_v1.newValue;
      render();
    }
  });
  globalThis.CacheTrayBillingUI = { open };
})();
